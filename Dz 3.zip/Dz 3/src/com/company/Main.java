package com.company;

public class Main {

    public static void main(String[] args) {
        double[] num = {9.1, -9.2, 9.3, 9.4, 9.5, -9.6, 9.7, -9.8, 9.9, 10.1, 10.2, 11.1, 12.3, 13.4, -14.8};
        for (double tempNum : num) {
            System.out.println(tempNum);

        }
        for (double tempNum : num) {
            if (d ) {
                intermediateResult += tempNum;
                amountOfElement++;
            }
            if (tempNum < 0) {
                b = true;
            }

        }
        result = intermediateResult / amountOfElement;
        System.out.println(result);
    }

}

